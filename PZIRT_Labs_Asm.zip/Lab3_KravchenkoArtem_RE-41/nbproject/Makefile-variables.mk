#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
# default configuration
CND_ARTIFACT_DIR_default=dist/default/production
CND_ARTIFACT_NAME_default=Lab3_KravchenkoArtem_RE-41.production.hex
CND_ARTIFACT_PATH_default=dist/default/production/Lab3_KravchenkoArtem_RE-41.production.hex
CND_PACKAGE_DIR_default=${CND_DISTDIR}/default/package
CND_PACKAGE_NAME_default=lab3kravchenkoartemre-41.tar
CND_PACKAGE_PATH_default=${CND_DISTDIR}/default/package/lab3kravchenkoartemre-41.tar
